//
//  LinkPlayBonjourSDK.h
//  LinkPlayBonjourSDK
//
//  Created by sunyu on 2019/5/24.
//  Copyright © 2019 sunyu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <LinkPlayBonjourSDK/LPDeviceProtocol.h>
#import <LinkPlayBonjourSDK/LPServiceManager.h>
//! Project version number for LinkPlayBonjourSDK.
FOUNDATION_EXPORT double LinkPlayBonjourSDKVersionNumber;

//! Project version string for LinkPlayBonjourSDK.
FOUNDATION_EXPORT const unsigned char LinkPlayBonjourSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LinkPlayBonjourSDK/PublicHeader.h>



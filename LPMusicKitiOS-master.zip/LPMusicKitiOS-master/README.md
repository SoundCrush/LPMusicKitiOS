# LPMusicKitiOS

[English](README.md) | [中文](README_zh.md)

Linkplay Music Kit is the app side SDK for Linkplay Home Audio solution；you can use it to implement our solution into your product.

MusicKit mainly solves 2 issues：

- Maintain the commnunication protocol with our firmware so that your app could interact with the device without concerning the comlexity of the lower layers.

- Wrapper the complexity of cloud services (includes music services and voice services etc.) so that you can intergtate them rapidly and don't bother the details.

## Documentation

You can find documentation [on the website](https://linkplayapp.github.io/linkplay_sdk_doc/en/).

## How To Get Started

- [Download LPMusicKitiOS](https://github.com/linkplayapp/LPMusicKitiOS/archive/master.zip) and import SDK to your project

## SDK Demo
###  1. SDK demo with CocoaPods
- [LPMusicKitPodsDemo](https://github.com/linkplayapp/LPMusicKitPodsDemo)

###  2. SDK demo
- [LPMusicKitDemo](https://github.com/linkplayapp/LPMusicKitDemo)


## Requirements

- iOS >= 10.0

## Installation

###  1. Installationwith CocoaPods

LPMusicKitiOS is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
platform :ios, '10.0'

target 'your_target_name' do

   pod "LPMusicKitiOS", :git => "https://github.com/linkplayapp/LPMusicKitiOS.git"

end
```
- iOS12 Access WiFi Information
![image](./images/Wi-Fi.jpg)
- iOS13 Apply for location permission, add NSLocationWhenInUseUsageDescription in Info.plist file
![image](./images/Location.jpg)
- iOS14 applies for Local Network and Bonjour services permissions, and adds NSBonjourServices and NSLocalNetworkUsageDescription permissions to the Info.plist file
![image](./images/LocalNetwork.jpg)

Then run the `pod update` command in the root directory of project.
For use of CocoaPods, please refer to the [CocoaPods Guides](https://guides.cocoapods.org/). It is recommended to update the CocoaPods to the latest version.

### 2. Manually configure your project

#### Step 1: Download LPMusicKitiOS

- [Download LPMusicKitiOS](https://github.com/linkplayapp/LPMusicKitiOS/archive/master.zip)

#### Step 2: Import Framework

- Import LPMusicKit.framework、LinkPlayBonjourSDK.framework
![image](./images/Framework.jpg)

#### Step 3: Import Tripartite Library

- Import dependent libraries AFNetworking、CocoaLumberjack、KissXML and tripartite library in LPMusicKitiOS/Third
![image](./images/Third.jpg)
#### Step 4: Import dependent libraries

- Import Lib related libraries in Link Binary With Libraries
![image](./images/Libraries.jpg)

#### Step 5: Xcode project settings

- In Build Settings, set the value of Other Linker Flags to -ObjC
![image](./images/BuildSetting.jpg)
- Header Search Paths: Add /usr/include/libxml2
![image](./images/HeaderPath.jpg)
- iOS12 Access WiFi Information
![image](./images/Wi-Fi.jpg)
- iOS13 Apply for location permission, add NSLocationWhenInUseUsageDescription in Info.plist file
![image](./images/Location.jpg)
- iOS14 applies for Local Network and Bonjour services permissions, and adds NSBonjourServices and NSLocalNetworkUsageDescription permissions to the Info.plist file
![image](./images/LocalNetwork.jpg)

## Author

LinkPlay, ios_team@linkplay.com

//
//  LPViewController.m
//  LPMusicKitiOS
//
//  Created by 675744097@qq.com on 05/15/2020.
//  Copyright (c) 2020 675744097@qq.com. All rights reserved.
//

#import "LPViewController.h"

@interface LPViewController ()

@end

@implementation LPViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

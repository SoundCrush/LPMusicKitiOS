//
//  LPViewController.h
//  LPMusicKitiOS
//
//  Created by 675744097@qq.com on 05/15/2020.
//  Copyright (c) 2020 675744097@qq.com. All rights reserved.
//

@import UIKit;

@interface LPViewController : UIViewController

@end

//
//  main.m
//  LPMusicKitiOS
//
//  Created by 675744097@qq.com on 05/15/2020.
//  Copyright (c) 2020 675744097@qq.com. All rights reserved.
//

@import UIKit;
#import "LPAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([LPAppDelegate class]));
    }
}

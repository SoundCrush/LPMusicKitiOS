# LPMusicKitiOS

[English](README.md) | [中文](README_zh.md)

Linkplay Music Kit是Linkplay Home Audio方案的app端SDK；通过它，您可以快速的将我们的解决方案实现到您的产品里。

MusicKit主要解决了两方面的问题：

- 维护与固件的通讯协议，使您可以简洁的与设备进行交互而不必关心琐碎的通讯技术问题

- 封装了网络服务（音乐服务、智能语音服务等）的复杂度，使您可以快速接入它们而不必关心实现细节

## 文档

你可以在这里找到更多[文档](https://linkplayapp.github.io/linkplay_sdk_doc/zh-hans/introduction.html) 。

## 下载SDK

- [下载 LPMusicKitiOS](https://github.com/linkplayapp/LPMusicKitiOS/archive/master.zip) 并且导入SDK到你的工程中

## SDK Demo
###  1. 使用 CocoaPods 安装SDK的demo
- [LPMusicKitPodsDemo](https://github.com/linkplayapp/LPMusicKitPodsDemo)

###  2. 手动导入SDK的demo
- [LPMusicKitDemo](https://github.com/linkplayapp/LPMusicKitDemo)

## 需求

- iOS >= 10.0

## 安装

###  1. 使用 CocoaPods 安装

LPMusicKitiOS 可以通过 [CocoaPods](https://cocoapods.org) 安装. 将下面的代码添加到您的pod文件里即可：

```ruby
platform :ios, '10.0'

target 'your_target_name' do

   pod "LPMusicKitiOS", :git => "https://github.com/linkplayapp/LPMusicKitiOS.git"

end
```

然后在项目根目录下执行 `pod update` 命令进行集成。

_CocoaPods 的使用请参考：[CocoaPods Guides](https://guides.cocoapods.org/)_
_CocoaPods 建议更新至最新版本_

- 申请Wi-Fi 权限
![image](./images/Wi-Fi.jpg)
- iOS13申请定位权限, Info.plist 文件中添加 NSLocationWhenInUseUsageDescription
![image](./images/Location.jpg)
- iOS14申请Local Network 和 Bonjour services 权限，Info.plist 文件中添加 NSBonjourServices 和 NSLocalNetworkUsageDescription 权限
![image](./images/LocalNetwork.jpg)


### 2. 手动配置项目

#### Step 1: 下载 LPMusicKitiOS
- [下载 LPMusicKitiOS](https://github.com/linkplayapp/LPMusicKitiOS/archive/master.zip)
#### Step 2: 导入SDK
- 导入 LPMusicKit.framework、LinkPlayBonjourSDK.framework两个Framework
![image](./images/Framework.jpg)
#### Step 3: 导入三方库
- 导入AFNetworking、CocoaLumberjack、KissXML 和 LPMusicKitiOS/Third 中的三方库
![image](./images/Third.jpg)
#### Step 4: 导入依赖库
- 在Link Binary With Libraries 中导入Lib相关的库
![image](./images/Libraries.jpg)
#### Step 5: Xcode 工程设置
-  Build Settings, 设置 Other Linker Flags 的值为  -ObjC
![image](./images/BuildSetting.jpg)
- Header Search Paths: 添加 /usr/include/libxml2 路径
![image](./images/HeaderPath.jpg)
- 申请Wi-Fi 权限
![image](./images/Wi-Fi.jpg)
- iOS13申请定位权限, Info.plist 文件中添加 NSLocationWhenInUseUsageDescription
![image](./images/Location.jpg)
- iOS14申请Local Network 和 Bonjour services 权限，Info.plist 文件中添加 NSBonjourServices 和 NSLocalNetworkUsageDescription 权限
![image](./images/LocalNetwork.jpg)


## 作者

LinkPlay, ios_team@linkplay.com

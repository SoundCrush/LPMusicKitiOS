//
//  LPMediaSourceAction.h
//  LPMusicKit
//
//  Created by sunyu on 2020/2/26.
//  Copyright © 2020 Linkplay. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LPMediaSourceProtocol.h"
NS_ASSUME_NONNULL_BEGIN

@interface LPMediaSourceAction : NSObject
<LPMediaSourceProtocol>

@end

NS_ASSUME_NONNULL_END
